PACK FAVICON LVD — prêt pour le repo Portfolio

Copie les fichiers en gardant exactement cette arborescence :

src/app/favicon.ico
src/app/icon.png
src/app/apple-icon.png
public/icons/lvd-192.png
public/icons/lvd-512.png
public/icons/lvd-favicon-preview.png

Recommandé :
- supprimer l'ancien src/app/icon.tsx si présent
- garder favicon.ico + icon.png + apple-icon.png comme fichiers statiques
- les fichiers public/icons servent pour PWA / manifest / usages futurs
